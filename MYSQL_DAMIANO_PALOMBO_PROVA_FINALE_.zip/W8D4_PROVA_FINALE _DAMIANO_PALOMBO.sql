/*Il codice oltre rispettare in pieno le richieste assegnate, contiene approfondimenti di vario genere 
appresi anche con del materiale aggiuntivo.*/

CREATE DATABASE ToysGroup;
USE ToysGroup;
-- Creazione tabella Category
CREATE TABLE IF NOT EXISTS Category (
CategoryId INT not null AUTO_INCREMENT,
CategoryName varchar (50),
CONSTRAINT PK_CategoryId PRIMARY KEY (CategoryId)
);
-- approfondimento: modifica tabella inserendo colonna

ALTER TABLE Category
ADD Descrizione varchar (200) default 'non presente';

-- Creazione tabella Product
CREATE TABLE IF NOT EXISTS Product (
ProductId INT not null AUTO_INCREMENT,
CategoryId INT,        
ProductName varchar (50) not null,
Prezzo decimal (8,2),
Disponibilità varchar (20) not null default 'terminato',
DataInserimento DATETIME  DEFAULT CURRENT_TIMESTAMP,   -- approfondimento: avrò data e ora attuale al momento dell'inserimento lasciando vuoto il campo nell'INSERT
DataModifica DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, -- approfondimento: avrò data e ora attuale al momento dell'UPDATE
CONSTRAINT PK_ProductId PRIMARY KEY (ProductId),
CONSTRAINT FK_Category_Product FOREIGN KEY (CategoryId) REFERENCES Category (CategoryId)
);
-- approfondimento: modificare nome colonna
ALTER TABLE Product
RENAME COLUMN Prezzo TO ListPrice;

-- Creazione tabella State
CREATE TABLE IF NOT EXISTS State (
StateId INT not null AUTO_INCREMENT,
StateName varchar (100) not null,
GeographicalAreaId INT not null unique,
CONSTRAINT PK_StateId PRIMARY KEY (StateId)
);

-- Creazione tabella Region 
CREATE TABLE IF NOT EXISTS Region(
RegionId INT not null AUTO_INCREMENT,
CountryRegionName varchar (50),   
City varchar (50) not null,
ResellerId INT not null unique,
PostalCode varchar (17)  null, 
-- PostalCode data_type 'varchar' perchè lo '0' con cuipotrebbe iniziare il PostalCode non è considerato come carattere da 'INT'
GeographicalAreaId INT not null,
CONSTRAINT PK_RegionId PRIMARY KEY (RegionId),
CONSTRAINT FK_State_Region FOREIGN KEY (GeographicalAreaId) REFERENCES State (GeographicalAreaId)  
);
-- approfondimento: aggiungere una colonna
ALTER TABLE Region
ADD EmailReseller varchar (50);

-- approfondimento: aggiungere un vincolo di unicità alla colonna
ALTER TABLE Region
ADD CONSTRAINT UQ_EmailReseller UNIQUE (EmailReseller);

/* approfondimento: cancella colonna
ALTER TABLE Region
DROP COLUMN EmailReseller;
*/

-- approfondimento: modificare data_type
ALTER TABLE Region
MODIFY PostalCode VARCHAR(25);

/*approfondimento: modificare nome colonna e data_type (fare attenzione se le tabelle sono popolate e non c'è compatibilità
 con data_type si rischia di perdere dati)*/

ALTER TABLE Region
CHANGE PostalCode ZipCode CHAR(10);

-- Creazione tabella Sales
CREATE TABLE IF NOT EXISTS Sales (
SalesOrderNumber varchar (20),
SalesOrderLineNumber tinyint check (SalesOrderLineNumber >1 AND SalesOrderLineNumber <3000), 
-- approfondimento 'check' và ad eseguire un controllo sulla riga mettendo tra le parentesi tonde la condizione
ProductId INT,
OrderDate DATE,
ResellerId INT,
UnitPrice decimal (8,2),
OrderQuantity smallint,
CONSTRAINT PK_SalesOrderNumber PRIMARY KEY (SalesOrderNumber),
CONSTRAINT FK_Region_Sales FOREIGN KEY (ResellerId) REFERENCES Region (ResellerId)
);

-- approfondimento: aggiungere vincolo esterno alla colonna
ALTER TABLE Sales
ADD CONSTRAINT FK_Product_Sales FOREIGN KEY (ProductId) REFERENCES Product (ProductId);

-- Popolazione della tabella Category
INSERT INTO Category (CategoryName, Descrizione) VALUES
('Giochi da Tavolo', 'Giochi di società e intrattenimento'),
('Action Figures', 'Personaggi d\'azione collezionabili'),
('Puzzle', 'Puzzle di vari formati e difficoltà'),
('Giochi Educativi', 'Giocattoli per imparare divertendosi');

-- Popolazione della tabella Product
INSERT INTO Product (CategoryId, ProductName, ListPrice, Disponibilità) VALUES
(1, 'Monopoli', 29.99, 'disponibile'),
(1, 'Cluedo', 25.99, default),
(2, 'Superman Figure', 45.50, 'disponibile'),
(2, 'Batman Figure', 49.90, default),
(3, 'Puzzle 1000 Pezzi', 15.75, 'disponibile'),
(3, 'Puzzle 500 Pezzi', 10.50, 'disponibile'),
(4, 'Kit Chimica', 35.20, 'disponibile'),
(4, 'Set Matematica', 22.80, default),
(1, 'Risk', 40.00, 'disponibile'),
(3, 'Puzzle 2000 Pezzi', 25.99, default);

-- Popolazione della tabella State
INSERT INTO State (StateName, GeographicalAreaId) VALUES
('Italia', 1),
('Francia', 2),
('Germania', 3),
('Stati Uniti', 4),
('Regno Unito', 5),
('Canada', 6),
('Australia', 7),
('Giappone', 8),
('Brasile', 9),
('India', 10);

-- Popolazione della tabella Region
INSERT INTO Region (CountryRegionName, City, ResellerId, ZipCode, GeographicalAreaId, EmailReseller) VALUES
('Europa', 'Roma', 1, '00100', 1, 'roma@example.com'),
('Europa', 'Parigi', 2, '75000', 2, 'parigi@example.com'),
('Europa', 'Berlino', 3, '10115', 3, 'berlino@example.com'),
('America', 'New York', 4, '10001', 4, 'newyork@example.com'),
('Europa', 'Londra', 5, 'E1 6AN', 5, 'londra@example.com'),
('America', 'Toronto', 6, 'M4B 1B3', 6, 'toronto@example.com'),
('Oceania', 'Sydney', 7, '2000', 7, 'sydney@example.com'),
('Asia', 'Tokyo', 8, '100-0001', 8, 'tokyo@example.com'),
('Sud America', 'San Paolo', 9, '01000-000', 9, 'saopaolo@example.com'),
('Asia', 'Mumbai', 10, '400001', 10, 'mumbai@example.com');

-- Popolazione della tabella Sales
INSERT INTO Sales (SalesOrderNumber, SalesOrderLineNumber, ProductId, OrderDate, ResellerId, UnitPrice, OrderQuantity) VALUES
('ORD001', 10, 1, '2023-05-01', 1, 29.99, 50),
('ORD002', 11, 2, '2023-06-15', 2, 25.99, 30),
('ORD003', 12, 3, '2023-07-20', 3, 45.50, 20),
('ORD004', 13, 5, '2023-08-10', 4, 15.75, 60),
('ORD005', 14, 6, '2023-09-01', 5, 10.50, 40),
('ORD006', 15, 7, '2022-12-25', 6, 35.20, 15),
('ORD007', 16, 9, '2024-03-10', 7, 40.00, 25),
('ORD008', 17, 5, '2023-04-30', 8, 22.80, 10),
('ORD009', 18, 3, '2023-11-11', 9, 15.75, 5),
('ORD010', 19, 1, '2024-01-15', 10, 29.99, 20);


-- approfondimento: modifico dati all'interno della tabella Product e in automatico mi aggiornerà anche la colonna DataModifica.

-- START TRANSACTION; 
/*inizio modifiche temporanee che verranno eliminate se incontrano ROLLBACK o rese definitive se incontrano COMMIT
(non contiene un numero troppo elevato di modifiche e non funziona con statement come CREATE o ALTER TABLE)*/

UPDATE Product
SET ListPrice = 54.99
WHERE ProductId = 1;

-- ROLLBACK;
SELECT DataModifica
FROM Product;
-- approfondimento: cambiare formato data
SELECT DataInserimento,
DataModifica,
DATE_FORMAT(DataInserimento, '%e %M, %Y') AS DataInserimentoFormattata
FROM Product;


-- Esplorazione conoscitiva tabelle
SELECT * 
FROM category;
SELECT * 
FROM product;
SELECT * 
FROM region;
SELECT * 
FROM sales;
SELECT * 
FROM state;


/* Task4
Esercizio 1
Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).
*/

SELECT CategoryId, COUNT(*)
FROM Category
GROUP BY CategoryId
HAVING COUNT(*) > 1;

SELECT ProductId, COUNT(*)
FROM Product
GROUP BY ProductId
HAVING COUNT(*) > 1;

SELECT StateId, COUNT(*)
FROM State
GROUP BY StateId
HAVING COUNT(*) > 1;

SELECT RegionId, COUNT(*)
FROM Region
GROUP BY RegionId
HAVING COUNT(*) > 1;

SELECT SalesOrderNumber, COUNT(*)
FROM Sales
GROUP BY SalesOrderNumber
HAVING COUNT(*) > 1;

/*approfondimento: Visuale panoramica di tutte le PK contenute nelle tabelle 'category' di tutti gli schemi presenti in locale,
cambiare solo nome_tabella e continuare la ricerca se desiderato*/
SELECT 
*
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'category'
 AND CONSTRAINT_NAME IN (
SELECT CONSTRAINT_NAME
      FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
      WHERE TABLE_NAME = 'category'
        AND CONSTRAINT_TYPE = 'PRIMARY KEY');
 
 
 /* Esercizio 2
 Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto,
 il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 
 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/
 

 
 SELECT SalesOrderNumber,
 OrderDate,
 ProductName,
 CategoryName,
 StateName,
 CountryRegionName,
 CASE WHEN DATEDIFF(CURRENT_DATE, OrderDate) > 180 THEN 'True' 
 WHEN DATEDIFF(CURRENT_DATE, OrderDate) <= 180 THEN 'False'
 END AS Più180GiorniOrderDate
 FROM Sales AS s
 INNER JOIN Product AS p
 ON s.ProductId = p.ProductId
 INNER JOIN Category AS c
 ON c.CategoryId = p.CategoryId
 INNER JOIN Region AS r
 ON r.ResellerId = s.ResellerId
 INNER JOIN State AS st
 ON st.GeographicalAreaId = r.GeographicalAreaId;
 /* Esercizio 3
Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate 
nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano).
 Nel result set devono comparire solo il codice prodotto e il totale venduto.*/
 
 -- Prima soluzione
 
 SELECT 
    ProductId,
    SUM(OrderQuantity) AS TotaleVenduto
FROM 
    Sales
WHERE 
    YEAR(OrderDate) = (
        SELECT MAX(YEAR(OrderDate)) 
        FROM Sales
    )
GROUP BY 
    ProductId
HAVING 
    SUM(OrderQuantity) > ( 
        SELECT 
            AVG(TotalePerProdotto)
        FROM (
            SELECT 
                SUM(OrderQuantity) AS TotalePerProdotto
            FROM 
                Sales
            WHERE 
                YEAR(OrderDate) = (
                    SELECT MAX(YEAR(OrderDate)) 
                    FROM Sales
                )
            GROUP BY 
                ProductId
        ) AS TotaliProdotti
    );
-- Seconda soluzione con query separate

-- Passo 1: Calcolo dell'ultimo anno censito
WITH UltimoAnno AS (
    SELECT YEAR(MAX(OrderDate)) AS Anno
    FROM Sales
),
-- Passo 2: Calcolo della media delle quantità vendute nell'ultimo anno
MediaVendite AS (
    SELECT AVG(OrderQuantity) AS MediaQuantità
    FROM Sales
    WHERE YEAR(OrderDate) = (SELECT Anno FROM UltimoAnno)
),
-- Passo 3: Calcolo del totale delle vendite per prodotto
VenditeTotali AS (
    SELECT 
        ProductId, 
        SUM(OrderQuantity) AS QuantitàTotale
    FROM Sales
    WHERE YEAR(OrderDate) = (SELECT Anno FROM UltimoAnno)
    GROUP BY ProductId
),
-- Passo 4: Individuazione dei prodotti con quantità maggiore della media
ProdottiFiltrati AS (
    SELECT 
        ProductId, 
        QuantitàTotale
    FROM VenditeTotali
    WHERE QuantitàTotale > (SELECT MediaQuantità FROM MediaVendite)
)
-- Passo 5: Restituzione del result set 
SELECT 
    P.ProductId, 
    P.QuantitàTotale
FROM ProdottiFiltrati P
JOIN Product PR ON P.ProductId = PR.ProductId;

/*Esercizio 4
 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

SELECT 
YEAR(S.OrderDate) AS Anno,
p.ProductName,
SUM(UnitPrice * OrderQuantity) AS FatturatoTotale
FROM Product as p 
JOIN Sales AS s
ON p.ProductId = s.ProductId
GROUP BY YEAR(OrderDate), s.ProductId;

/*Esercizio 5
 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/
SELECT YEAR(OrderDate) AS Anno,
 StateName,
SUM(OrderQuantity*UnitPrice) AS FatturatoTotale
FROM Sales AS s
JOIN Region AS r
ON S.ResellerId= R.ResellerId
JOIN State AS st
ON r.GeographicalAreaId= st.GeographicalAreaId
GROUP BY YEAR(OrderDate), StateName
ORDER BY YEAR(OrderDate) DESC, FatturatoTotale DESC; -- nell'interpretazione della traccia ho inteso entrambi i campi richiesti in ordine decrescente altrimenti se la data la intende cresce è necessario togliere DESC da OrderDate

/* Esercizio 6
Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT 
    C.CategoryName AS Categoria,
    SUM(S.OrderQuantity) AS TotaleArticoli
FROM 
    Sales S
JOIN 
    Product P ON S.ProductId = P.ProductId
JOIN 
    Category C ON P.CategoryId = C.CategoryId
GROUP BY 
    C.CategoryName
ORDER BY 
    TotaleArticoli DESC
LIMIT 1;

/*Esercizio 7
	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.*/
-- Primo modo con SubQuery
SELECT ProductId,
ProductName
FROM Product
WHERE ProductId NOT IN (
    SELECT DISTINCT ProductId
    FROM Sales
);

-- Secondo modo join con condizione
SELECT 
    P.ProductId,
    P.ProductName
FROM 
    Product P
LEFT JOIN 
    Sales S ON P.ProductId = S.ProductId
WHERE 
    S.ProductId IS NULL;
   
   -- terzo modo con COALESCE
    SELECT 
    P.ProductId,
    P.ProductName
FROM 
    Product P
LEFT JOIN (
    SELECT 
        ProductId,
        SUM(OrderQuantity) AS TotaleVenduto
    FROM 
        Sales
    GROUP BY 
        ProductId
) AS Vendite ON P.ProductId = Vendite.ProductId
WHERE 
    COALESCE(Vendite.TotaleVenduto, 0) = 0;


/*Esercizio 8 
Creare una vista sui prodotti in modo tale 
da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)*/

CREATE VIEW VistaProdotto AS 
SELECT ProductId,
ProductName,
CategoryName
FROM Product p 
JOIN Category c 
ON p.CategoryId = c.CategoryId;

SELECT * 
FROM VistaProdotto;
/*Esercizio 9
 Creare una vista per le informazioni geografiche*/

CREATE VIEW VistaGeo AS
SELECT 
CountryRegionName,
StateName,
City
FROM Region r
JOIN State s 
ON r.GeographicalAreaId= s.GeographicalAreaId;

SELECT * 
FROM vistageo;

-- approfondimento:modificare una Vista in base ad una condizione(Eliminare il commento nella query sottostante per verificarne la veridicità) 
/*CREATE OR REPLACE VIEW VistaGeo AS
SELECT *
FROM Region
WHERE  CountryRegionName = 'Europa';
SELECT * 
FROM VISTAGEO;/* 

/* approfondimento: clonare tabella per poter lavorare in maniera libera magari quando il DB è condiviso e consultato anche da
altri utenti senza compromettere dati originali e inserimento dati nella tabella.
(trasporta struttura e dati)*/

CREATE TABLE ProductClone
LIKE Product;
INSERT INTO ProductClone
SELECT * 
FROM Product;

SELECT *
FROM ProductClone;

DROP TABLE ProductClone;

/* Se si volesse lavorare solo con dati contententi in tabella per uno scopo puramente sperimentale 
senza compromettere dati originali e senza aver l'esigenza di mettere in relazione le tabelle (copia solo dati senza constraint)*/

CREATE TABLE ProductClone
SELECT * FROM Product;
DROP TABLE ProductClone;


-- approfondimento: con una combinazione tra due comandi riesco ad avere una ricerca più selettiva

SELECT COUNT(DISTINCT CountryRegionName) AS TotaliContinentiInteressati
FROM Region;      
SELECT * FROM Region;

/*approfondimento: Se ci venisse posto il quesito 
Rispondere alla seguente domanda: qual è la seconda categoria di articoli meno richiesta dal mercato?
introdurremo lo stentement OFFSET dopo il LIMIT*/
SELECT 
    C.CategoryName AS Categoria,
    SUM(S.OrderQuantity) AS TotaleArticoli
FROM 
    Sales S
JOIN 
    Product P ON S.ProductId = P.ProductId
JOIN 
    Category C ON P.CategoryId = C.CategoryId
GROUP BY 
    C.CategoryName
ORDER BY 
    TotaleArticoli ASC
LIMIT 1
OFFSET 1;

/*approfondimento: sulla ricerca con stentament 'LIKE'. Nel caso in cui dovessimo cercare nella colonna CountryRegionName
una parola che finisca con 'ia' e non volessimo che il resultset sia troppo generico (quindi utilizzando il simbolo '%' prima di 'ia')
è necessario l'uso degli underscore '_' che rappresentano 1 carattere per ogni underscore e otterremo un resultset molto specifico che faccia
quindi distinzione tra 'Asia' e 'Oceaina' in questo caso specifico.*/
SELECT *
FROM Region
WHERE CountryRegionName LIKE '%ia';

SELECT *
FROM Region
WHERE CountryRegionName LIKE '__ia';
SELECT *
FROM Region
WHERE CountryRegionName LIKE '_____ia';

-- approfondimento su stringhe di testo

-- Per ottenere il nome dei prodotti convertito in maiuscolo.
SELECT UPPER(ProductName) AS NomeMaiuscolo
FROM Product;

-- Per ottenere il nome dei prodotti convertito in minuscolo.
SELECT LOWER(ProductName) AS ProductNameMinuscolo
FROM Product;

-- Per ottenere la lunghezza del ZipCode di tutte le città.
SELECT City,
LENGTH(ZipCode) AS LunghezzaPostalCode
FROM Region;

-- Per ottenere il ResellerId concatenato con la loro email, separati da tre spazi.
SELECT CONCAT(ResellerId, '   ',EmailReseller) AS ResellerId_email
FROM Region;

-- Per ottenere l'indirizzo email dei Reseller senza il dominio.
SELECT SUBSTRING_INDEX(EmailReseller, '@', 1) AS NickName
FROM Region;

-- Per ottenere i primi tre caratteri del ProductName per tutti i prodotti.
SELECT LEFT(ProductName, 3) AS PrimiTreCaratteriProductName
FROM Product;

-- Per ottenere l'ultima parola della categoria di ogni prodotto.
SELECT SUBSTRING_INDEX(CategoryName, ' ', -1) AS UltimaParolaCategoryName
FROM Category;

-- Per ottenere il numero di caratteri distinti presenti nella descrizione di ogni prodotto.
SELECT LENGTH(REPLACE(Descrizione, ' ', '')) AS NumeroCaratteriDescrizione
FROM Category;

-- Per ottenere la posizione del numero '0' in ogni ZipCode. (prende in considerazione il primo '0' che incontra)
SELECT ZipCode,
LOCATE('0', ZipCode) AS Posizione0ZipCode
FROM Region;

/*Per ottenere la descrizione della categoria del prodotto con
 il testo "Giocattoli per imparare divertendosi" sostituito da "Giocattoli divertiti, impara, costruisci".*/
SELECT CategoryName,
REPLACE(Descrizione, 'Giocattoli per imparare divertendosi', 'Giocattoli divertiti, impara, costruisci') AS DescrizioneModificata
FROM Category;

-- Per ottenere il nome del prodotto con spazi aggiunti per raggiungere la lunghezza di 20 caratteri.
SELECT LPAD(ProductName, 20, ' ') AS ProductNameConSpazi
FROM Product;

